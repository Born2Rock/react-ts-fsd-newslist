export { AppImage } from '@/shared/ui/AppImage/AppImage';
