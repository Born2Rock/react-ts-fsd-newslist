export const USER_LOCALSTORAGE_KEY = 'user_';
export const ARTICLES_VIEW_LOCALSTORAGE_KEY = 'articles_view';
export const LOCAL_STORAGE_THEME_KEY = 'theme';
