export enum Theme {
  LIGHT = 'app_light_theme',
  DARK = 'app_dark_theme',
  PURPLE = 'app_purple_theme',
}
