export { ProfileCard } from './ui/ProfileCard/ProfileCard';
export type { Profile } from './model/types/profile';
