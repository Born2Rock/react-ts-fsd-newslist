export enum Country {
  Russia = 'Russia',
  Belarus = 'Belarus',
  Kazakhstan = 'Kazahstan',
  Armenia = 'Armenia',
}
