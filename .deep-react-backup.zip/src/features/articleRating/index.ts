export { ArticleRating } from './ui/ArticleRating/ArticleRating';
