export { MainPageAsync as MainPage } from '@/pages/MainPage/ui/MainPage.async';
