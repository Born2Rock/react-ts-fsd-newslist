export { AdminPanelPageAsync as AdminPanelPage } from './ui/AdminPanelPage.async';
