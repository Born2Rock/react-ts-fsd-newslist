import { lazy } from 'react';

export const AdminPanelPageAsync = lazy(() => import('./AdminPanelPage'));
