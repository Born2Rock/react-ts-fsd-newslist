export { AboutPageAsync as AboutPage } from './ui/AboutPage.async';
