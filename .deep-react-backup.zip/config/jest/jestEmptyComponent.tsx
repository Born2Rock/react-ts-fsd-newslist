import React from 'react';

function jestEmptyComponent() {
  return <div />;
}

export default jestEmptyComponent;
